#!/bin/sh
#GNU
echo "installing..."
sudo apt-get install git -y
echo "done..."
sudo apt-get update -y
echo "done..."
sudo apt-get upgrade -y
echo "done..."
sudo apt-get install wget -y
echo "done..."
sudo apt-get install python2-pip -y
echo "done..."
sudo apt-get install perl -y
echo "done..."
sudo apt-get install Build essential -y
echo "done..."
sudo apt-get install libany-uri-escape-perl -y
echo "done..."
sudo apt-get install libhtml-html5-entities-perl -y
echo "done..."
sudo apt-get install libhtml-entities-numbered-perl -y
echo "done..."
sudo apt-get install libhtml-parser-perl -y
echo "done..."
sudo apt-get install libwww-perl -y
echo "done..."
sudo apt-get install php -y
echo "done..."
echo "now u u need install the requirements with command \033[32mpip install -r requirements.txt\033[1;37m"
echo "Ok"
