import time
# Set color
R = '\033[31m' # Red
N = '\033[1;37m' # White
G = '\033[32m' # Green
O = '\033[0;33m' # Orange
B = '\033[1;34m' #Blue
time.sleep(1)
print(""+N+"")
print("     Darksploit Park, System Security Interface")
print("     Version 0.1")
print("     Ready...")
print("     > access security")
print("     access: PERMISSION DENIED.")
print("     > access security grid")
print("     access: PERMISSION DENIED.")
print("     > access main security grid")
print("     access: PERMISSION DENIED....and...")
print(""+R+"     YOU DIDN'T SAY THE MAGIC WORD!")
print("     YOU DIDN'T SAY THE MAGIC WORD!")
print("     YOU DIDN'T SAY THE MAGIC WORD!")
print("     YOU DIDN'T SAY THE MAGIC WORD!")
print("     YOU DIDN'T SAY THE MAGIC WORD!")
print("     YOU DIDN'T SAY THE MAGIC WORD!")
print("     YOU DIDN'T SAY THE MAGIC WORD!")
